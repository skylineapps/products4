require 'rails_helper'

RSpec.describe ProductsController, type: :controller do
	def index

	end

end
